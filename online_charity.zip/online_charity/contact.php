<?php
include("header.php");
?>

<div id="page-header">

<div class="section-bg" style="background-image: url(img/background-2.jpg);"></div>


<div class="container">
<div class="row">
<div class="col-md-12">
<div class="header-content">
<h1>Contact us</h1>
</div>
</div>
</div>
</div>

</div>

</header>


<div class="section">

<div class="container">

<div class="row">

<main id="main" class="col-md-7">

<div class="article causes-details">



<div class="article-tags-share">


<ul class="share">
<li>SHARE:</li>
<li><a href="#"><i class="fa fa-twitter"></i></a></li>
<li><a href="#"><i class="fa fa-facebook"></i></a></li>
<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
<li><a href="#"><i class="fa fa-instagram"></i></a></li>
</ul>

</div>


<div class="article-reply">
<h3>Contact us.</h3>
<p>Leave a message...</p>
<form>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<input class="input" placeholder="Name" type="text">
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<input class="input" placeholder="Email" type="email">
</div>
</div>
<div class="col-md-12">
<div class="form-group">
<input class="input" placeholder="Subject" type="text">
</div>
</div>
<div class="col-md-12">
<div class="form-group">
<textarea class="input" placeholder="Message"></textarea>
</div>
<button class="primary-button">Submit</button>
</div>
</div>
</form>
</div>

</div>

</main>


<aside id="aside" class="col-md-5">

<div class="widget">
<h3 class="widget-title">Address</h3>
<div class="widget-category">
 MetBridge Charity,
    DYPIMCA, Akurdi
    Pune_411044
</div>
</div>


<div class="widget">
<h3 class="widget-title">Contact No.</h3>
<div class="widget-category">
9158829220
</div>
</div>

<div class="widget">
<h3 class="widget-title">Email ID.</h3>
<div class="widget-category">
medbridge123@gmailcom
</div>
</div>

</aside>

</div>

</div>

</div>

<?php
include("footer.php");
?>